
package area.of.geometric.shapes;


public class AreaOfGeometricShapes {

   
    public static void main(String[] args) {
        Shape s1=new Shape("squer",12,34);
        Shape s2=new Shape("retangle",21,32);
        Shape listofAreas[]=new Shape[3];
        listofAreas[0]=s1;
        listofAreas[1]=s2;
        listofAreas[2]=new Shape("circle",23,45);
        
        Opertion opr=new Opertion("Opertion of area",listofAreas);
        for (int i = 0; i <  listofAreas.length; i++) {
            
            System.out.println("Shape : "+ listofAreas[i].nameshapes);
            System.out.println("length of the shape : "+listofAreas[i].length);
            System.out.println("width of the shape : "+ listofAreas[i].width);
            System.out.println("******************************");
        }
    }
    
}
